
package repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Area;

@Repository
public interface AreaRepository extends JpaRepository<Area, Integer> {

	//The ratio, the count, the minimum, the maximum, the average, and the
	//standard deviation of the number of brotherhoods per area
	@Query("select a.brotherhoods.size from Area a ")
	Double[] ratioCountMinMaxAvgAndStddevOfBrotherhoodsByArea();
}
