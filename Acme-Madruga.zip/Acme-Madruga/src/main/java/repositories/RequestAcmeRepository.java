
package repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.RequestAcme;

@Repository
public interface RequestAcmeRepository extends JpaRepository<RequestAcme, Integer> {

	//The ratio of requests to march in a procession, grouped by their status.
	@Query("select count(r)*1.0/(select count(s) from RequestAcme s where s.procession.id=?1) from RequestAcme r where r.procession.id=?1 group by r.status")
	Double[] ratioRequestsByStatus(int id);

	//The ratio of requests to march grouped by status
	@Query("select count(r)*1.0/(select count(s) from RequestAcme s) from RequestAcme r group by r.status")
	Double[] ratioRequestsByStatus();
}
