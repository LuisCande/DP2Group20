
package domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

@Entity
@Access(AccessType.PROPERTY)
public class RequestAcme extends DomainEntity {

	//Attributes

	private Status		status;
	private Integer		rowAcme;
	private Integer		columnAcme;
	private String		reason;

	//Relationships

	private Member		member;
	private Procession	procession;


	//Getters 

	@NotNull
	@Valid
	public Status getStatus() {
		return this.status;
	}

	@NotNull
	@Min(value = 0)
	public Integer getRowAcme() {
		return this.rowAcme;
	}

	@NotNull
	@Min(value = 0)
	public Integer getColumnAcme() {
		return this.columnAcme;
	}

	//TODO habr� que setearle una reason cualquiera en el create/save como haciamos con las apps
	@NotBlank
	public String getReason() {
		return this.reason;
	}

	@Valid
	@NotNull
	@ManyToOne(optional = false)
	public Member getMember() {
		return this.member;
	}

	@Valid
	@NotNull
	@ManyToOne(optional = false)
	public Procession getProcession() {
		return this.procession;
	}

	//Setters

	public void setProcession(final Procession procession) {
		this.procession = procession;
	}

	public void setMember(final Member member) {
		this.member = member;
	}

	public void setRowAcme(final Integer rowAcme) {
		this.rowAcme = rowAcme;
	}

	public void setColumnAcme(final Integer columnAcme) {
		this.columnAcme = columnAcme;
	}

	public void setReason(final String reason) {
		this.reason = reason;
	}

	public void setStatus(final Status status) {
		this.status = status;
	}
}
