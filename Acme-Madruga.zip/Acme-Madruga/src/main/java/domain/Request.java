
package domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

@Entity
@Access(AccessType.PROPERTY)
public class Request extends DomainEntity {

	//Attributes

	private Status		status;
	private Integer		row;
	private Integer		column;
	private String		reason;

	//Relationships

	private Member		member;
	private Procession	procession;


	//Getters 

	@NotNull
	@Valid
	public Status getStatus() {
		return this.status;
	}

	@NotNull
	@Min(value = 0)
	public Integer getRow() {
		return this.row;
	}

	@NotNull
	@Min(value = 0)
	public Integer getColumn() {
		return this.column;
	}

	//TODO habr� que setearle una reason cualquiera en el create/save como haciamos con las apps
	@NotBlank
	public String getReason() {
		return this.reason;
	}

	@Valid
	@NotNull
	@ManyToOne(optional = false)
	public Member getMember() {
		return this.member;
	}

	@Valid
	@NotNull
	@ManyToOne(optional = false)
	public Procession getProcession() {
		return this.procession;
	}

	//Setters

	public void setProcession(final Procession procession) {
		this.procession = procession;
	}

	public void setMember(final Member member) {
		this.member = member;
	}

	public void setRow(final Integer row) {
		this.row = row;
	}

	public void setColumn(final Integer column) {
		this.column = column;
	}

	public void setReason(final String reason) {
		this.reason = reason;
	}

	public void setStatus(final Status status) {
		this.status = status;
	}
}
