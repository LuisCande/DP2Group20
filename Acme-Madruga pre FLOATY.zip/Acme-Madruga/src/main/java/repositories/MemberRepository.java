
package repositories;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Member;

@Repository
public interface MemberRepository extends JpaRepository<Member, Integer> {

	//Returns the collection of suspicious members.
	@Query("select m from Member m where m.suspicious = true")
	Collection<Member> suspiciousMembers();
}
