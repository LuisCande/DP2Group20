
package services;

import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.BrotherhoodRepository;
import security.Authority;
import security.UserAccount;
import domain.Box;
import domain.Brotherhood;
import domain.Enrolment;
import domain.Float;
import domain.Procession;
import domain.SocialProfile;

@Service
@Transactional
public class BrotherhoodService {

	//Managed repository ---------------------------------

	@Autowired
	private BrotherhoodRepository	brotherhoodRepository;

	//Supporting services --------------------------------

	@Autowired
	private BoxService				boxService;

	@Autowired
	private ActorService			actorService;


	//Simple CRUD Methods --------------------------------

	public Brotherhood create() {
		final Authority a = new Authority();
		a.setAuthority(Authority.BROTHERHOOD);
		final UserAccount account = new UserAccount();
		account.setAuthorities(Arrays.asList(a));
		account.setBanned(false);

		final Brotherhood brotherhood = new Brotherhood();
		brotherhood.setSpammer(false);
		brotherhood.setSocialProfiles(new ArrayList<SocialProfile>());
		brotherhood.setUserAccount(account);
		brotherhood.setBoxes(new ArrayList<Box>());

		brotherhood.setProcessions(new ArrayList<Procession>());
		brotherhood.setEnrolments(new ArrayList<Enrolment>());
		brotherhood.setFloats(new ArrayList<Float>());

		return brotherhood;
	}

	public Collection<Brotherhood> findAll() {
		return this.brotherhoodRepository.findAll();
	}

	public Brotherhood findOne(final int id) {
		Assert.notNull(id);

		return this.brotherhoodRepository.findOne(id);
	}

	public Brotherhood save(final Brotherhood brotherhood) {
		Assert.notNull(brotherhood);
		Brotherhood saved2;

		//TODO sobra un assert? este o el de checkAddress? Comprobar cuando est� en local todo ya.
		//Assertion to make sure the address is either null or written but not blank spaces.
		Assert.isTrue(!"\\s".equals(brotherhood.getAddress()) || brotherhood.getAddress() == null);

		//Assertion that the email is valid according to the checkAdminEmail method.
		Assert.isTrue(this.actorService.checkUserEmail(brotherhood.getEmail()));

		//TODO checkear que si creamos un actor SIN address y luego creamos un objeto con ese actor, no peta al llamar a este save.
		//Assertion to check that the address isn't just a white space.
		Assert.isTrue(this.actorService.checkAddress(brotherhood.getAddress()));

		//Assertion that the phone is valid according to the checkPhone method.
		Assert.isTrue(this.actorService.checkPhone(brotherhood.getPhone()));

		//Checking if the actor is bannable according to the "bannableActors" query.
		if (this.actorService.isBannable(brotherhood) == true)
			brotherhood.setSpammer(true);

		//Assertion to make sure that the pictures are URLs
		if (brotherhood.getPictures() != null && !brotherhood.getPictures().isEmpty())
			this.checkPictures(brotherhood.getPictures());

		if (brotherhood.getId() != 0) {
			Assert.isTrue(this.actorService.findByPrincipal().getId() == brotherhood.getId());
			saved2 = this.brotherhoodRepository.save(brotherhood);
		} else {
			final Brotherhood saved = this.brotherhoodRepository.save(brotherhood);
			this.actorService.hashPassword(saved);
			saved.setBoxes(this.boxService.generateDefaultFolders(saved));
			saved2 = this.brotherhoodRepository.save(saved);
		}

		return saved2;
	}

	public void delete(final Brotherhood brotherhood) {
		Assert.notNull(brotherhood);

		//Assertion that the user deleting this brotherhood has the correct privilege.
		Assert.isTrue(this.actorService.findByPrincipal().getId() == brotherhood.getId());

		this.brotherhoodRepository.delete(brotherhood);
	}
	//CheckPictures method
	public boolean checkPictures(final String pictures) {
		boolean result = true;
		if (pictures != null)
			if (!pictures.isEmpty()) {
				final String[] splited = pictures.split(";");
				for (final String s : splited)
					if (!this.isURL(s))
						result = false;
			}
		return result;
	}
	public boolean isURL(final String url) {
		try {
			new URL(url);
			return true;
		} catch (final Exception e) {
			return false;
		}
	}

	//Other methods

	//Returns the enrolmentable brotherhoods given a member id
	public Collection<Brotherhood> nonEnrolmentableBrotherhoods(final int memberId) {
		return this.brotherhoodRepository.nonEnrolmentableBrotherhoods(memberId);
	}

	//Returns the enrolmentable members given a brotherhood id
	public Collection<Brotherhood> nonEnrolmentableMembers(final int brotherhoodId) {
		return this.brotherhoodRepository.nonEnrolmentableMembers(brotherhoodId);
	}

	//Returns the brotherhoods given a member id
	public Collection<Brotherhood> enrolmentMemberBrotherhoods(final int memberId) {
		return this.brotherhoodRepository.enrolmentMemberBrotherhoods(memberId);
	}

	//Returns the collection of spammer brotherhoods.
	public Collection<Brotherhood> spammerBrotherhoods() {
		return this.brotherhoodRepository.spammerBrotherhoods();
	}

	//The largest brotherhoods
	//TODO Revisar esto porque actualmente solo estamos devolviendo una y pueden ser 2 con el mismo numero de enrolments
	public Collection<Brotherhood> largestBrotherhoods() {
		final ArrayList<Brotherhood> brotherhoods = (ArrayList<Brotherhood>) this.brotherhoodRepository.largestBrotherhoods();
		if (brotherhoods.size() >= 1) {
			final ArrayList<Brotherhood> top = new ArrayList<Brotherhood>(brotherhoods.subList(brotherhoods.size() - 1, brotherhoods.size()));
			return top;
		} else
			return brotherhoods;
	}

	//The smallest brotherhoods
	//TODO Revisar esto porque actualmente solo estamos devolviendo una y pueden ser 2 con el mismo numero de enrolments
	public Collection<Brotherhood> smallestBrotherhoods() {
		final ArrayList<Brotherhood> brotherhoods = (ArrayList<Brotherhood>) this.brotherhoodRepository.smallestBrotherhoods();
		if (brotherhoods.size() >= 1) {
			final ArrayList<Brotherhood> top = new ArrayList<Brotherhood>(brotherhoods.subList(brotherhoods.size() - 1, brotherhoods.size()));
			return top;
		} else
			return brotherhoods;
	}
}
