
package services;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.FloatAcmeRepository;
import domain.FloatAcme;

@Service
@Transactional
public class FloatAcmeService {

	//Managed repository

	@Autowired
	private FloatAcmeRepository	floatAcmeRepository;

	@Autowired
	private ActorService		actorService;


	//Supporting services --------------------------------

	//Simple CRUD methods

	public Collection<FloatAcme> findAll() {
		return this.floatAcmeRepository.findAll();
	}

	public FloatAcme findOne(final int id) {
		Assert.notNull(id);

		return this.floatAcmeRepository.findOne(id);
	}

	public FloatAcme save(final FloatAcme floatAcme) {
		Assert.notNull(floatAcme);

		//Assertion that the user modifying this configuration has the correct privilege.
		Assert.isTrue(this.actorService.findByPrincipal().getId() == floatAcme.getProcession().getBrotherhood().getId());

		final FloatAcme saved = this.floatAcmeRepository.save(floatAcme);
		//		this.actorService.checkSpam(saved.getSystemName());
		//		this.actorService.checkSpam(saved.getBanner());
		//		this.actorService.checkSpam(saved.getWelcomeEN());
		//		this.actorService.checkSpam(saved.getWelcomeES());
		return saved;
	}
	public void delete(final FloatAcme floatAcme) {
		Assert.notNull(floatAcme);

		//Assertion that the user deleting this administrator has the correct privilege.
		Assert.isTrue(this.actorService.findByPrincipal().getId() == floatAcme.getProcession().getBrotherhood().getId());

		this.floatAcmeRepository.delete(floatAcme);
	}
}
