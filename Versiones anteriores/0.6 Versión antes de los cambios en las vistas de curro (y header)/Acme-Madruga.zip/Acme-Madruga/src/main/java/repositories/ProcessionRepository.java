
package repositories;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Procession;

@Repository
public interface ProcessionRepository extends JpaRepository<Procession, Integer> {

	//The processions that are going to be organised in 30 days or less.
	@Query("select p from Procession p where p.moment-(CURRENT_TIMESTAMP+1) < 99000000")
	Collection<Procession> processionsBefore30Days();
}
