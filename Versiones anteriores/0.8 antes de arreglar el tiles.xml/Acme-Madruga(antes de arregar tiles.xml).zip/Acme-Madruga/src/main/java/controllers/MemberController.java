
package controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import services.ActorService;
import services.BrotherhoodService;
import services.MemberService;
import domain.Member;

@Controller
@RequestMapping("member")
public class MemberController extends AbstractController {

	//Services

	@Autowired
	private MemberService		memberService;

	@Autowired
	private BrotherhoodService	brotherhoodService;

	@Autowired
	private ActorService		actorService;


	//List

	//TODO Necesito sacar los miembros de una hermandad, se tiene que hacer una query
	//	@RequestMapping(value = "/listByBrotherhood", method = RequestMethod.GET)
	//	public ModelAndView listByBrotherhood(@RequestParam final int varId) {
	//		final ModelAndView result;
	//		final Collection<Member> members;
	//
	//		final Brotherhood b = this.brotherhoodService.findOne(varId);
	//		members =
	//
	//		result = new ModelAndView("members/list");
	//		result.addObject("members", members);
	//		result.addObject("requestURI", "member/list.do");
	//
	//		return result;
	//	}

	//Ancillary methods

	protected ModelAndView createEditModelAndView(final Member member) {
		ModelAndView result;

		result = this.createEditModelAndView(member, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final Member member, final String messageCode) {
		ModelAndView result;

		result = new ModelAndView("member/edit");
		result.addObject("member", member);
		result.addObject("message", messageCode);
		result.addObject("requestURI", "member/edit.do");

		return result;
	}
}
