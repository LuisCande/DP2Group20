
package services;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.ProcessionRepository;
import domain.Brotherhood;
import domain.FloatAcme;
import domain.Procession;
import domain.RequestAcme;

@Service
@Transactional
public class ProcessionService {

	//Managed repository

	@Autowired
	private ProcessionRepository	processionRepository;

	//Supporting services

	@Autowired
	private ActorService			actorService;


	//Simple CRUD methods

	public Procession create() {
		final Procession p = new Procession();

		p.setTicker(this.generateTicker());

		final Brotherhood b = (Brotherhood) this.actorService.findByPrincipal();
		p.setBrotherhood(b);
		p.setFinalMode(false);
		p.setRequestsAcme(new ArrayList<RequestAcme>());
		p.setFloatsAcme(new ArrayList<FloatAcme>());

		return p;
	}
	public Procession findOne(final int id) {
		Assert.notNull(id);

		return this.processionRepository.findOne(id);
	}

	public Collection<Procession> findAll() {
		return this.processionRepository.findAll();
	}

	public Procession save(final Procession p, final boolean b) {
		Assert.notNull(p);

		//Assertion to make sure that the procession is not on final mode.
		Assert.isTrue(p.getFinalMode() == false);

		//Assertion that the user modifying this task has the correct privilege.
		Assert.isTrue(this.actorService.findByPrincipal().getId() == p.getBrotherhood().getId());

		if (b == true)
			p.setFinalMode(true);

		//TODO m�todo checkSpam
		final Procession saved = this.processionRepository.save(p);
		//		this.actorService.checkSpam(saved.getAddress());
		//		this.actorService.checkSpam(saved.getDescription());

		return saved;
	}
	public void delete(final Procession p) {
		Assert.notNull(p);

		//A procession cannot be deleted if it's in final mode.
		Assert.isTrue(p.getFinalMode() == false);

		//A procession cannot be deleted if it has any float.
		Assert.isTrue(p.getFloatsAcme().isEmpty());

		//A procession cannot be deleted if it has any request.
		Assert.isTrue(p.getRequestsAcme().isEmpty());

		//Assertion that the user deleting this task has the correct privilege.
		Assert.isTrue(this.actorService.findByPrincipal().getId() == p.getBrotherhood().getId());

		this.processionRepository.delete(p);
	}

	//Other methods

	//Generates the first half of the unique tickers.
	private String generateNumber() {
		final Date date = new Date();
		final DateFormat fecha = new SimpleDateFormat("yyyy/MM/dd");
		final String convertido = fecha.format(date);

		final String[] campos = convertido.split("/");
		final String year = campos[0].trim().substring(2, 4);
		final String month = campos[1].trim();
		final String day = campos[2].trim();

		final String res = year + month + day;
		return res;
	}

	//Generates the alpha-numeric part of the unique tickers.
	private String generateString() {
		final Random c = new Random();
		String randomString = "";
		int i = 0;
		final int longitud = 6;
		while (i < longitud) {
			randomString += ((char) ((char) c.nextInt(26) + 65)); //mayus
			i++;
		}
		return randomString;
	}

	//Generates both halves of the unique ticker and joins them with a dash.
	public String generateTicker() {
		final String res = this.generateNumber() + "-" + this.generateString();
		return res;
	}

	//Ancillary methods 

}
