
package services;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.AreaRepository;
import security.Authority;
import domain.Area;

@Service
@Transactional
public class AreaService {

	//Managed repository

	@Autowired
	private AreaRepository	areaRepository;

	@Autowired
	private ActorService	actorService;


	//Supporting services --------------------------------

	//Simple CRUD methods

	public Collection<Area> findAll() {
		return this.areaRepository.findAll();
	}

	public Area findOne(final int id) {
		Assert.notNull(id);

		return this.areaRepository.findOne(id);
	}

	public Area save(final Area area) {
		Assert.notNull(area);

		final Authority authAdmin = new Authority();
		authAdmin.setAuthority(Authority.ADMIN);
		//Assertion that the user modifying this area has the correct privilege.
		Assert.isTrue(this.actorService.findByPrincipal().getUserAccount().getAuthorities().contains(authAdmin));

		final Area saved = this.areaRepository.save(area);
		//		this.actorService.checkSpam(saved.getSystemName());
		//		this.actorService.checkSpam(saved.getBanner());
		//		this.actorService.checkSpam(saved.getWelcomeEN());
		//		this.actorService.checkSpam(saved.getWelcomeES());
		return saved;
	}
	public void delete(final Area area) {
		Assert.notNull(area);

		final Authority authAdmin = new Authority();
		authAdmin.setAuthority(Authority.ADMIN);
		//Assertion that the user modifying this sponsorship has the correct privilege.
		Assert.isTrue(this.actorService.findByPrincipal().getUserAccount().getAuthorities().contains(authAdmin));

		this.areaRepository.delete(area);
	}
}
