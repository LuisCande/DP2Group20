
package services;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.RequestAcmeRepository;
import domain.RequestAcme;

@Service
@Transactional
public class RequestAcmeService {

	//Managed repository

	@Autowired
	private RequestAcmeRepository	requestAcmeRepository;

	@Autowired
	private ActorService			actorService;


	//Supporting services --------------------------------

	//Simple CRUD methods

	public Collection<RequestAcme> findAll() {
		return this.requestAcmeRepository.findAll();
	}

	public RequestAcme findOne(final int id) {
		Assert.notNull(id);

		return this.requestAcmeRepository.findOne(id);
	}

	public RequestAcme save(final RequestAcme requestAcme) {
		Assert.notNull(requestAcme);

		//TODO hay que hacer todo lo del estado y dem�s

		//Assertion that the user modifying this request has the correct privilege.
		Assert.isTrue(this.actorService.findByPrincipal().getId() == requestAcme.getMember().getId());

		final RequestAcme saved = this.requestAcmeRepository.save(requestAcme);

		return saved;
	}
	public void delete(final RequestAcme requestAcme) {
		Assert.notNull(requestAcme);

		//Assertion that the user modifying this request has the correct privilege.
		Assert.isTrue(this.actorService.findByPrincipal().getId() == requestAcme.getMember().getId());

		this.requestAcmeRepository.delete(requestAcme);
	}
}
