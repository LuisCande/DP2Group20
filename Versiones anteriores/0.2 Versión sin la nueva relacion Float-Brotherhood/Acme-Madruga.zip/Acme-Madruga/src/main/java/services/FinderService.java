
package services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.FinderRepository;
import security.Authority;
import domain.Actor;
import domain.Finder;
import domain.Member;
import domain.Procession;

@Service
@Transactional
public class FinderService {

	//Managed service

	@Autowired
	private FinderRepository		finderRepository;

	//Supporting service

	@Autowired
	private ActorService			actorService;

	@Autowired
	private ConfigurationService	configurationService;

	@Autowired
	private MemberService			memberService;


	//Simple CRUD methods --------------------------------

	public Finder create() {
		final Finder f = new Finder();
		f.setProcessions(new ArrayList<Procession>());
		return f;
	}

	public Finder findOne(final int id) {
		Assert.notNull(id);
		return this.finderRepository.findOne(id);
	}

	public Collection<Finder> findAll() {
		return this.finderRepository.findAll();
	}

	public Finder save(final Finder f) {
		Assert.notNull(f);
		//Assertion that the user modifying this finder has the correct privilege.
		Assert.isTrue(f.getId() == this.findPrincipalFinder().getId());//this.findPrincipalFinder().getId()
		//If all fields of the finder are null, the finder returns the entire listing of available tasks.
		f.setMoment(new Date(System.currentTimeMillis() - 1));
		final Finder saved = this.finderRepository.save(f);
		//TODO CheckSpam
		//this.actorService.checkSpam(saved.getKeyWord());
		return saved;
	}

	public void delete(final Finder f) {
		Assert.notNull(f);

		//Assertion that the user deleting this finder has the correct privilege.
		Assert.isTrue(this.actorService.findByPrincipal().getId() == this.memberService.memberByFinder(f.getId()).getId());

		this.finderRepository.delete(f);
	}

	public Finder findPrincipalFinder() {
		final Actor a = this.actorService.findByPrincipal();
		final Authority auth = new Authority();
		auth.setAuthority(Authority.MEMBER);
		Assert.isTrue(a.getUserAccount().getAuthorities().contains(auth));

		final Member m = (Member) this.actorService.findOne(a.getId());
		Finder fd = new Finder();
		if (m.getFinder() == null) {
			fd = this.create();
			final Finder saved = this.finderRepository.save(fd);
			m.setFinder(saved);
			this.memberService.save(m);
			return saved;
		} else
			return m.getFinder();
	}

	//	public Collection<Procession> find(final Finder finder) {
	//		Assert.notNull(finder);
	//		Collection<Procession> fixUpTasks = new ArrayList<>(), results = new ArrayList<>();
	//		String keyWord = finder.getKeyWord();
	//		Double minPrice = finder.getMinPrice(), maxPrice = finder.getMaxPrice();
	//		Date dateStart = finder.getDateStart(), dateEnd = finder.getDateEnd();
	//
	//		if (finder.getKeyWord() == null)
	//			keyWord = "";
	//		if (finder.getMinPrice() == null)
	//			minPrice = 0.0;
	//		if (finder.getMaxPrice() == null)
	//			maxPrice = 9999999.9;
	//		if (finder.getDateStart() == null)
	//			dateStart = new Date(631152000L);
	//		if (finder.getDateEnd() == null)
	//			dateEnd = new Date(2524694400000L);
	//
	//		final Collection<Procession> firstResults = this.findFixUpTasks(keyWord, minPrice, maxPrice, dateStart, dateEnd);
	//		Collection<Procession> secondResults = new ArrayList<>();
	//		Collection<Procession> thirdResults = new ArrayList<>();
	//
	//		if (finder.getCategory() != null)
	//			secondResults = this.fixUpTaskService.fixUpTasksByCategory(finder.getCategory().getId());
	//		else
	//			secondResults = this.fixUpTaskService.findAll();
	//
	//		if (finder.getWarranty() != null)
	//			thirdResults = this.fixUpTaskService.fixUpTasksByWarranty(finder.getWarranty().getId());
	//		else
	//			thirdResults = this.fixUpTaskService.findAll();
	//
	//		fixUpTasks = this.intersection(this.intersection(firstResults, secondResults), thirdResults);
	//		results = this.limitResults(fixUpTasks);
	//		return results;
	//	}

	public Collection<Procession> limitResults(final Collection<Procession> fixUpTasks) {
		Collection<Procession> results = new ArrayList<>();
		final int maxResults = this.configurationService.findAll().iterator().next().getMaxFinderResults();
		if (fixUpTasks.size() > maxResults)
			results = new ArrayList<Procession>(((ArrayList<Procession>) fixUpTasks).subList(0, maxResults));
		else
			results = fixUpTasks;
		return results;
	}

	//	private Collection<Procession> intersection(final Collection<Procession> a, final Collection<Procession> b) {
	//		final Collection<Procession> c = new ArrayList<>();
	//		final Collection<Procession> mayor = a.size() > b.size() ? a : b;
	//		for (final Procession f : mayor)
	//			if (a.contains(f) && b.contains(f))
	//				c.add(f);
	//		return c;
	//	}

	//	//Search processions 
	//	public Collection<Procession> findFixUpTasks(final String keyWord, final Double minPrice, final Double maxPrice, final Date dateStart, final Date dateEnd) {
	//		return this.finderRepository.findProcessions(keyWord, minPrice, maxPrice, dateStart, dateEnd);
	//	}
}
