
package services;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.RequestRepository;
import domain.Request;

@Service
@Transactional
public class RequestService {

	//Managed repository

	@Autowired
	private RequestRepository	requestRepository;

	@Autowired
	private ActorService		actorService;


	//Supporting services --------------------------------

	//Simple CRUD methods

	public Collection<Request> findAll() {
		return this.requestRepository.findAll();
	}

	public Request findOne(final int id) {
		Assert.notNull(id);

		return this.requestRepository.findOne(id);
	}

	public Request save(final Request request) {
		Assert.notNull(request);

		//TODO hay que hacer todo lo del estado y dem�s

		//Assertion that the user modifying this request has the correct privilege.
		Assert.isTrue(this.actorService.findByPrincipal().getId() == request.getMember().getId());

		final Request saved = this.requestRepository.save(request);

		return saved;
	}
	public void delete(final Request request) {
		Assert.notNull(request);

		//Assertion that the user modifying this request has the correct privilege.
		Assert.isTrue(this.actorService.findByPrincipal().getId() == request.getMember().getId());

		this.requestRepository.delete(request);
	}
}
